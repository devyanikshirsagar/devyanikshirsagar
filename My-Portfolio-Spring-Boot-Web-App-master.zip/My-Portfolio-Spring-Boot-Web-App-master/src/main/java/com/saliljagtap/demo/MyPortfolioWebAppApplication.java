package com.saliljagtap.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyPortfolioWebAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyPortfolioWebAppApplication.class, args);
	}

}
